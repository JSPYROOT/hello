<?php if(!defined("RUN_MODE")) die();?>
<?php
$config->company->editor = new stdclass();
$config->company->editor->setbasic = array('id' => 'desc,content', 'tools' => 'full');
