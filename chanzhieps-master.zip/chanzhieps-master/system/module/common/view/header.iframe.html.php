<?php if(!defined("RUN_MODE")) die();?>
<?php include dirname(__FILE__) . DS . 'header.lite.html.php';?>
<div class='iframe-container'>
