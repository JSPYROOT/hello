<?php if(!defined("RUN_MODE")) die();?>
<div class='row'><div class='u-1'><?php $common->printPositionBar();?></div></div>
