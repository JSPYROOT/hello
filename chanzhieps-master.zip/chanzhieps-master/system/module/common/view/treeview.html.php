<?php if(!defined("RUN_MODE")) die();?>
<script language='javascript'>$(function() {$(".tree").treeview({collapsed: false, unique: false}) })</script>
