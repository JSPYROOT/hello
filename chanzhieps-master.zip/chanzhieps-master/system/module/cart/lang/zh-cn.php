<?php if(!defined("RUN_MODE")) die();?>
<?php
$lang->cart->common = '购物车';
$lang->cart->browse = '我的购物车';

$lang->cart->noProducts     = "购物车内没有商品。";
$lang->cart->pickProducts   = "去挑选商品";
$lang->cart->goAccount      = "去结算";
$lang->cart->goHome         = "返回首页";

$lang->cart->topbarInfo     = "<i class='icon icon-shopping-cart text-danger'></i> 购物车<font class='text-danger'>%s</font>";
