<?php if(!defined("RUN_MODE")) die();?>
<?php
/**
 * The article category zh-cn file of chanzhiEPS.
 *
 * @copyright   Copyright 2009-2015 青岛易软天创网络科技有限公司(QingDao Nature Easy Soft Network Technology Co,LTD, www.cnezsoft.com)
 * @license     ZPLV1.2 (http://zpl.pub/page/zplv12.html)
 * @author      Xiying Guan <guanxiying@xirangit.com>
 * @package     blog
 * @version     $Id$
 * @link        http://www.chanzhi.org
 */
$lang->blog->common    = 'Blog';
$lang->blog->home      = 'Home';
$lang->blog->siteHome  = 'Site';
$lang->blog->subscribe = 'Subscribe Blog';
