<?php if(!defined("RUN_MODE")) die();?>
<?php
$lang->address->common  = 'Address';
$lang->address->address = 'addree';
$lang->address->phone   = 'Phone';
$lang->address->zipcode = 'zipcode';
$lang->address->contact = 'contact';

$lang->address->browse = 'Address List';
$lang->address->create = 'Add new Address';
$lang->address->edit   = 'Edit address';
