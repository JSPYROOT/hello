<?php if(!defined("RUN_MODE")) die();?>
<?php include 'latestproduct.form.php';?>
