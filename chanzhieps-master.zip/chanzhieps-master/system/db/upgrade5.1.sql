ALTER table `eps_article`  CHANGE `contribution` `submittion` enum('0', '1', '2', '3') NOT NULL DEFAULT '0';
